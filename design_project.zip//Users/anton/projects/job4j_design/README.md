# job4j_design

## Tемы, пройденные в проекте:

Maven

Iterator

Generic

List

Set

Map

Tree

Ввод-вывод

Socket

Логгирование

Сериализация

PostgreSQL

JDBC
